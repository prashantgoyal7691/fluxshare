from collections import deque

# Chessboard size
N = 8

# All 8 knight moves
moves = [
    (-2, -1),
    (-2,  1),
    (-1, -2),
    (-1,  2),
    ( 1, -2),
    ( 1,  2),
    ( 2, -1),
    ( 2,  1)
]


# BFS Function
def knight_bfs(start, goal):

    queue = deque()

    queue.append((start[0], start[1], 0, [start]))
    # row, col, moves_count, path

    visited = set()
    visited.add(start)

    while queue:

        r, c, dist, path = queue.popleft()

        # goal found
        if (r, c) == goal:

            return dist, path

        # generate neighbors
        for dr, dc in moves:

            nr = r + dr
            nc = c + dc

            # bounds checking
            if 0 <= nr < N and 0 <= nc < N:

                if (nr, nc) not in visited:

                    visited.add((nr, nc))

                    queue.append((
                        nr,
                        nc,
                        dist + 1,
                        path + [(nr, nc)]
                    ))

    return -1, []


# Start and Goal
start = (0, 0)
goal = (7, 7)

# Run BFS
min_moves, path = knight_bfs(start, goal)


# OUTPUT
print("MINIMUM MOVES =", min_moves)

print("\nPATH:\n")

for step in path:
    print(step)


# Valid moves from (0,0)
print("\nVALID MOVES FROM (0,0):")

for dr, dc in moves:

    nr = 0 + dr
    nc = 0 + dc

    if 0 <= nr < N and 0 <= nc < N:
        print((nr, nc))


# Tricky Part
moves_11, path_11 = knight_bfs((0,0), (1,1))

print("\nMINIMUM MOVES FROM (0,0) TO (1,1) =", moves_11)

print("\nPATH TO (1,1):")

for step in path_11:
    print(step)