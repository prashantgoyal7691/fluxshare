import heapq

# -----------------------------------
# GRAPH
# -----------------------------------

graph = {
    'A': [('B', 4), ('C', 3)],

    'B': [('A', 4), ('D', 5), ('E', 2)],

    'C': [('A', 3), ('F', 4)],

    'D': [('B', 5), ('H', 8)],

    'E': [('B', 2), ('C', 6), ('H', 5)],

    'F': [('C', 4), ('G', 3)],

    'G': [('F', 3), ('H', 2)],

    'H': [('D', 8), ('E', 5), ('G', 2)]
}


# -----------------------------------
# HEURISTIC VALUES
# -----------------------------------

heuristic = {
    'A': 10,
    'B': 8,
    'C': 7,
    'D': 5,
    'E': 4,
    'F': 6,
    'G': 2,
    'H': 0
}


# -----------------------------------
# A* SEARCH
# -----------------------------------

def astar(start, goal):

    # (f, g, node, path)
    pq = []

    heapq.heappush(
        pq,
        (
            heuristic[start],   # f = g+h
            0,                  # g
            start,
            [start]
        )
    )

    visited = set()

    step = 0

    while pq:

        f, g, node, path = heapq.heappop(pq)

        if node in visited:
            continue

        visited.add(node)

        step += 1

        print(f"\nSTEP {step}")

        print("Current Node:", node)

        print("g(n) =", g)

        print("h(n) =", heuristic[node])

        print("f(n) =", f)

        print("Path =", path)

        # GOAL FOUND
        if node == goal:

            return path, g

        # Explore neighbors
        for neighbor, cost in graph[node]:

            if neighbor not in visited:

                new_g = g + cost

                new_h = heuristic[neighbor]

                new_f = new_g + new_h

                print(
                    f"Push {neighbor} "
                    f"g={new_g} "
                    f"h={new_h} "
                    f"f={new_f}"
                )

                heapq.heappush(
                    pq,
                    (
                        new_f,
                        new_g,
                        neighbor,
                        path + [neighbor]
                    )
                )

    return None, None


# -----------------------------------
# RUN A*
# -----------------------------------

path, total_cost = astar('A', 'H')


# -----------------------------------
# FINAL OUTPUT
# -----------------------------------

print("\nFINAL PATH:\n")

for city in path:
    print(city, end=" ")

print("\n\nTOTAL COST =", total_cost)


# -----------------------------------
# COMPARISON
# -----------------------------------

print("\nBest First Search Path:")
print("A -> C -> E -> H")
print("Cost = 14")

print("\nA* Path:")
print(" -> ".join(path))
print("Cost =", total_cost)