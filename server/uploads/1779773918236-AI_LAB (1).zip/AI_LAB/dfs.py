
adj = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}
def dfs(st,goal):
    stack=[(st,st)]
    path=[(st,st)]
    visited=[st]
    while stack:
        cur,p=stack.pop()
        visited.append(cur)
        if(st==goal):
            path.append((cur,p))
            break
        for i in adj[cur]:
            if i in visited:
                continue    
            stack.append((i,cur))
            path.append((i,cur))

        p1=[goal]
        cur=goal
            
    while cur!=st:
        for c,p in path:
            if  c==cur:
                cur=p
                p1.append(p)
                break
    return p1

print(dfs('A','F'))





    
