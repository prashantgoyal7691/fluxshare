from queue import PriorityQueue

graph = {
    'A': [('B', 4), ('C', 3)],
    'B': [('A', 4), ('D', 5), ('E', 2)],
    'C': [('A', 3), ('E', 6), ('F', 4)],
    'D': [('B', 5), ('H', 8)],
    'E': [('B', 2), ('C', 6), ('H', 5)],
    'F': [('C', 4)],          # F-G removed
    'G': [('H', 2)],          # disconnected from F
    'H': [('D', 8), ('E', 5), ('G', 2)]
}

# Heuristic values h(n)
h = {
    'A': 10,
    'B': 8,
    'C': 7,
    'D': 5,
    'E': 4,
    'F': 6,
    'G': 2,
    'H': 0
}


def heu(st,goal):
    pq=PriorityQueue()
    pq.put((h[st],st,0,st))
    vi=[]
    path=[]
    total=0
    while not pq.empty():
        _,cur,cost,p=pq.get()
        if cur==goal:
            path.append((cur,p))
            vi.append(cur)
            total+=cost
            break
        else:
            for i in graph[cur]:
                path.append((cur,p))
                vi.append(cur)
                total+=cost
                pq.put((h[i[0]],i[0],i[1],cur))

    return path,total

print(heu('A','H'))
