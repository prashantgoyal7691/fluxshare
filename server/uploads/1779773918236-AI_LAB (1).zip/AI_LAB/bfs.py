
adj = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}

def bfs(adj,st,goal):
    queue=[(st,st)]
    path=[]
    visited=[]
    while queue:
        c,p=queue.pop(0)
        path.append((c,p))
        visited.append(c)
        if(c==goal):
            break
        else:
            for i in adj[c]:
                queue.append((i,c))
    return path
    
print(bfs(adj,'A','F'))